package tcp_server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Scanner;

import javax.swing.text.DefaultHighlighter;


public class server {
public static String msg;
public static DBHelper dbh;
public static Calendar calendar;

public static void main(String[] args) throws IOException, InterruptedException, NumberFormatException, SQLException{
	ServerSocket serverSocket=new ServerSocket(6000);
	dbh=new DBHelper("123", "127.0.0.1:3306", "root", "1555");
	dbh.DBConnection();
	//
//	int instruction_index = 3;
//	String sql = "SELECT * FROM instruction_from_php_to_java WHERE msg_id='"+instruction_index+"'";
//	System.out.println(sql);
//	ResultSet rs = server.dbh.sqlExecution(sql);
//	if(rs.next()){
//		String type_str=rs.getString("type"),subtype_str=rs.getString("subtype"),box_id_str=rs.getString("box_id"),paras_str=rs.getString("paras");
//		int type = Integer.parseInt(type_str);
//		int subtype = Integer.parseInt(subtype_str);
//		int box_id = Integer.parseInt(box_id_str);
//		double paras = Double.parseDouble(paras_str);
//		byte[] mString = Data_parse.Tx_data_parse(type, subtype, paras, box_id, instruction_index);
//		//
//		System.out.println(mString);
//		//
//		instruction_index++;
//	}
	//
//	String search_1="Select * FROM USER";
//	try {
//			ResultSet resultSet=dbh.sqlExecution(search_1);
//			while(resultSet.next()){
//			String name=resultSet.getString("name");
//			String id=resultSet.getString("user_id");
//			System.out.println("id:"+id+"  name:"+name);
//		}
//	} catch (SQLException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
	while(true){
		Socket socket=serverSocket.accept();
		if(socket.isConnected()){
			System.out.println("Connection Built");
			System.out.println(socket.getInetAddress());
			System.out.println(socket.getRemoteSocketAddress());
		}
		/*
		String str1,str2;
		BufferedReader TCP_reader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
		BufferedReader system_reader=new BufferedReader(new InputStreamReader(System.in));
		DataOutputStream output=new DataOutputStream(socket.getOutputStream());
		*/
		/////////
//		OutputStream os=socket.getOutputStream();
//		InputStream is=socket.getInputStream();
//		do{
//			msg="Hello World";
//			while(scanner.hasNextLine()){
//				msg=scanner.nextLine();
//			}
//			os.write(msg.getBytes());
//			is.read(bs);
//			int i=0;
//			while(bs[i]>0){
//				System.out.print((char)bs[i]);
//				i++;
//			}
//		}
//		while((!new String(bs).equals("bye")));
		/////////
		
		/*
		do{
			if((str1=TCP_reader.readLine())!=null){
			System.out.println("client:"+str1);
			}
			str2=system_reader.readLine();
			output.writeBytes(str2+'\n');
		}
		while(!str2.equals("end"));
		*/
		Server_thread st1,st2,st3;
		st1=new Server_thread(0, socket);
		st2=new Server_thread(1, socket);
		st3=new Server_thread(2, socket);
		st1.start();
		st2.start();
		st3.start();
		//socket.close();
	} 
}
}
