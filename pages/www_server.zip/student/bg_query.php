<?php
    include("../reg/conn.php");
    error_reporting(0);
    
    $rm_ip=$_SERVER['REMOTE_ADDR']; #正在浏览当前页面用户的 IP 地址。
    $rm_por=$_SERVER['REMOTE_PORT']; #用户连接到服务器时所使用的端口。
    
    $pwd=mysql_real_escape_string($_POST['pwd']);
    $i=mysql_real_escape_string($_POST['i']);
    $n=mysql_real_escape_string($_POST['n']);
    $dp=mysql_real_escape_string($_POST['dp']);
    $db=mysql_real_escape_string($_POST['db']);
    $dr=mysql_real_escape_string($_POST['dr']);
    
    //echo $pwd;

    mysql_query("INSERT INTO student_access 
    (time,ip,port,pwd,stuid,name,depart,dorm_build,dorm_room)
    VALUES 
    (sysdate(),'$rm_ip','$rm_por','$pwd','$i','$n','$dp','$db','$dr');");

    echo mysql_error();
    if(!isset($_POST['pwd'])||!($_POST['pwd']=="THwi_49%4"||$_POST['pwd']=="UtdK%3u_r")){
        $response="nope";
       exit(json_encode($response));
    }
    
    mysql_select_db("student", $conn);
    echo mysql_error();
    $sql="SELECT * FROM basic_info WHERE ";
    if($_POST['i']!=""){
        $sql.="student_id like '$i'";
        $ed=1;
    }
    if($_POST['n']!=""){
        if($ed==1)
            $sql.=" AND name like '$n'";
        else $sql .= "name like '$n'";
        $ed=1;
    }
    if($_POST['dp']!=""){
        if($ed==1)
            $sql.=" AND department like '$dp'";
        else $sql .= "department like '$dp'";
        $ed=1;
    }
    if($_POST['db']!=""){
        if($ed==1)
            $sql.=" AND dorm_build like '$db'";
        else $sql .= "dorm_build like '$db'";
        $ed=1;
    }
    if($_POST['dr']!=""){
        if($ed==1)
            $sql.=" AND dorm_room like '$dr'";
        else $sql .= "dorm_room like '$dr'";
        $ed=1;
    }
	if ($pwd=="UtdK%3u_r") $sql.= " AND department = '电机系'";
    $sql.=" ORDER by student_id asc LIMIT 10;";
    //echo $sql;
    if($check_query=mysql_query($sql)){
        while($result=mysql_fetch_array($check_query)){
            //print_r($result);
            $n=array('i'=>$result['student_id'],
            'n'=>$result['name'],
            's'=>$result['sex'],
            'dp'=>$result['department'],
            'cl'=>$result['class'],
            'db'=>$result['dorm_build'],
            'dr'=>$result['dorm_room'],
            'dbd'=>$result['dorm_bed']
            );
            $response[]=$n;
        }
    } 
    if(!isset($response))
        $response="nope";
    echo json_encode($response);
?>