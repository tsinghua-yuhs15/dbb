var d = {
    base: ""
};
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/jquery.jqplot.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/examples/syntaxhighlighter/scripts/shCore.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/examples/syntaxhighlighter/scripts/shBrushJScript.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/examples/syntaxhighlighter/scripts/shBrushXml.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.logAxisRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.canvasTextRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.canvasAxisLabelRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.canvasAxisTickRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.dateAxisRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.categoryAxisRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.barRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.pointLabels.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.dateAxisRenderer.min.js\"><\/script>");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/plugins/jqplot.dateAxisRenderer.min.js\"><\/script>");
document.write("<link class=\"include\" rel=\"stylesheet\" type=\"text/css\" href=\"/common/jqplot/jquery.jqplot.min.css\" />");
document.write("<link type=\"text/css\" rel=\"stylesheet\" href=\"/common/jqplot/examples/syntaxhighlighter/styles/shCoreDefault.min.css\" />");
document.write("<link type=\"text/css\" rel=\"stylesheet\" href=\"/common/jqplot/examples/syntaxhighlighter/styles/shThemejqPlot.min.css\" />");
document.write("<script language=\"JavaScript\" type=\"text/javascript\" src=\"/common/jqplot/m_jqplot.js\"><\/script>");